/* for example a table created in a database with some produtcs while u search
 in search for a particular product */
/* for example u searched for a product:phone , and brand name apple , price below 51000*/
SELECT
  name,
  price,  
  brand
FROM
  PRODUCT
WHERE   /* here by using where , we are giving particlar need*/
  name LIKE "phone"
  AND price <= 51000
  OR brand = "Apple"
ORDER BY /* by using this we can  arrange in ascending order or descending order*/
  price ASC
LIMIT  /* by using limit we can control the number of items from displaying */
  10;