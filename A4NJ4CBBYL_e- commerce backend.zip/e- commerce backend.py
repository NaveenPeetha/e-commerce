# for example if u want to buy a product 

class Product:
    def __init__(self, name , price , ratings): #assging values to names
        self.name = name
        self.price = price
        self.ratings = ratings
        
    def display_product_details(self): # displaying products 
        print("Product : {}" . format(self.name))
        print("Price : {}" . format(self.price))
        print("Rating : {}" . format(self.ratings))
 # for example if added  any electronicItem to cart       

class ElectronicItem(Product):
    pass # there will no same items for product so this class will be used for adding extra features

# for example if u added a laptop
added_cart = ElectronicItem("Laptop", 45000 , 4.1)
added_cart.display_product_details()